function colorChange(){
    document.body.style.backgroundColor = "#23374D";
    // console.log(bg);
}